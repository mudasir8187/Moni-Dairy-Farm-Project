﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MoniDairyForm
{
    public partial class Breeding : Form
    {
        SqlConnection con = new SqlConnection("Data Source = MONI\\SQLEXPRESS02; Initial Catalog = MoniDiaryFarm;Encrypt=False; Integrated Security = True");
        public Breeding()
        {
            InitializeComponent();
            show();
            FillCowID();
        }

        private void Breeding_Load(object sender, EventArgs e)
        {

        }

        private void cow_sideLabel_Click(object sender, EventArgs e)
        {
           Cows obj = new Cows();
           obj.Show();
           this.Hide();
        }

        private void milk_sideLabel_Click(object sender, EventArgs e)
        {
            MilkProduction obj = new MilkProduction();
            obj.Show();
            this.Hide();
        }

        private void sale_sideLabel_Click(object sender, EventArgs e)
        {
            Sales obj = new Sales();
            obj.Show();
            this.Hide();
        }

        private void finanace_sideLabel_Click(object sender, EventArgs e)
        {
            Finance obj = new Finance();
            obj.Show();
            this.Hide();
        }

        private void FillCowID()
        {
            con.Open();
            string query = "select CowID from CowsManage_Table";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader reader;
            reader = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Columns.Add("CowID", typeof(int));
            dt.Load(reader);
            cowID_cb.ValueMember = "CowID";
            cowID_cb.DataSource = dt;
            con.Close();
        }
        private void show()
        {
            con.Open();
            string showQ = "Select * from Breeding_Table";
            SqlCommand cmd = new SqlCommand(showQ, con);
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            adp.Fill(dt);
            breed_dgv.DataSource = dt;
            con.Close();
        }
        private void clear()
        {
            cowID_cb.Text = "";
            cowName_tb.Text = "";
            Age_tb.Text = "";
            key = 0;
        }
        private void getName()
        {
            con.Open();
            string query = "select * from CowsManage_Table where CowID =" + cowID_cb.SelectedValue.ToString() + "";
            SqlCommand cmd = new SqlCommand(query, con);
            DataTable dt = new DataTable();
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            adp.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                cowName_tb.Text = dr["CowName"].ToString();
                Age_tb.Text = dr["Age"].ToString();
                con.Close();
            }
        }

        private void cowID_cb_SelectionChangeCommitted(object sender, EventArgs e)
        {
            getName(); 
        }

        private void save_btn_Click(object sender, EventArgs e)
        {

            if (cowID_cb.SelectedIndex == -1 || cowName_tb.Text == "" || Age_tb.Text == "" )
            {
                MessageBox.Show("Please fill Missing Values");
            }
            else
            {
                try
                {
                    con.Open();
                    string query = "insert into Breeding_Table Values('" + heat_Date.Value.Date + "','" + breed_Date.Value.Date + "','" + cowID_cb.SelectedValue.ToString() + "','" + cowName_tb.Text + "','" + preg_Date.Value.Date + "','" + expect_Date.Value.Date + "','" + Calve_date.Value.Date +"','"+ Age_tb.Text+ "')";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show(" Breeding Data Saved Sucessfully.");
                    con.Close();
                    show();
                    clear();
                }
                catch (Exception exc)
                {
                    MessageBox.Show(exc.Message);
                }
                finally
                {
                    con.Close();
                }
            }
        }
        int key = 0;
        private void breed_dgv_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            heat_Date.Text = breed_dgv.SelectedRows[0].Cells[0].Value.ToString();
            breed_Date.Text = breed_dgv.SelectedRows[0].Cells[1].Value.ToString();
            cowID_cb.SelectedValue = breed_dgv.SelectedRows[0].Cells[2].Value.ToString();
            cowName_tb.Text = breed_dgv.SelectedRows[0].Cells[3].Value.ToString();
            preg_Date.Text = breed_dgv.SelectedRows[0].Cells[4].Value.ToString();
            expect_Date.Text = breed_dgv.SelectedRows[0].Cells[5].Value.ToString();
            Calve_date.Text = breed_dgv.SelectedRows[0].Cells[6].Value.ToString();
            Age_tb.Text = breed_dgv.SelectedRows[0].Cells[7].Value.ToString();
            if (cowName_tb.Text == "")
            {
                key = 0;
            }
            else
            {
                key = Convert.ToInt32(breed_dgv.SelectedRows[0].Cells[2].Value.ToString());
            }
        }
        private void update_btn_Click(object sender, EventArgs e)
        {
            if (cowID_cb.SelectedIndex == -1 || cowName_tb.Text == "" || Age_tb.Text == "" )
            {
                MessageBox.Show("Please select Data to be Updated!!");
            }
            else
            {
                try
                {
                    con.Open();
                    string query = "update Breeding_Table set HeatDate = '" + heat_Date.Text + "', BreedDate = '" + breed_Date.Text + "', CowID ='" + cowID_cb.Text + "', CowName = '" + cowName_tb.Text + "', PregnancyDate = '" + preg_Date.Text + "', ExpectedDateToCalve = '" + expect_Date.Text + "', CalveDate ='"+Calve_date.Text+ "', Age = '"+Age_tb.Text+"' where CowID = '" + key + "'";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Breed Data Updated Sucessfully.");
                    con.Close();
                    show();
                    clear();

                }
                catch (Exception exc)
                {
                    MessageBox.Show(exc.Message);
                }
                finally
                {
                    con.Close();
                }
            }
        }
        private void delete_btn_Click(object sender, EventArgs e)
        {
            if (cowID_cb.SelectedIndex == -1 || cowName_tb.Text == "" || Age_tb.Text == "")
            {
                MessageBox.Show("Please select Data to be Deleted!!");
            }
            else
            {
                con.Open();
                string showQ = "DELETE Breeding_Table WHERE CowID = '" + key + "';";
                SqlCommand cmd = new SqlCommand(showQ, con);
                SqlDataAdapter adp = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                adp.Fill(dt);
                breed_dgv.DataSource = dt;
                con.Close();
                MessageBox.Show("Breed Data Deleted Sucessfully!!");
                show();
                clear();
            }
        }

        private void cowID_cb_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
