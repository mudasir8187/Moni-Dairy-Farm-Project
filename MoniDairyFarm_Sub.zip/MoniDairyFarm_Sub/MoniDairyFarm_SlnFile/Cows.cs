﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;
using Microsoft.Data.SqlClient;
using System.Data.SqlTypes;

namespace MoniDairyForm
{
    public partial class Cows : Form
    {
        SqlConnection con = new SqlConnection("Data Source = MONI\\SQLEXPRESS02; Initial Catalog = MoniDiaryFarm;Encrypt=False; Integrated Security = True");
        public Cows()
        {
            InitializeComponent();
            show();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void cow_side_label_Click(object sender, EventArgs e)
        {
            // Cows obj = new Cows();
            // obj.Show();
            //  this.Hide();
        }

        private void milk_side_label_Click(object sender, EventArgs e)
        {
            MilkProduction obj = new MilkProduction();
            obj.Show();
            this.Hide();
        }

        private void Cows_Load(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {
            Breeding obj = new Breeding();
            obj.Show();
            this.Hide();
        }

        private void sale_sideLabel_Click(object sender, EventArgs e)
        {
            Sales obj = new Sales();
            obj.Show();
            this.Hide();
        }

        private void Finance_sideLabel_Click(object sender, EventArgs e)
        {
            Finance obj = new Finance();
            obj.Show();
            this.Hide();
        }
        decimal age = 00;
        private void save_btn_Click(object sender, EventArgs e)
        {
            string query = "insert into CowsManage_Table Values('" + cowName_tb.Text + "','" + earTag_tb.Text + "','" + cowColor_tb.Text + "','" + breed_tb.Text + "'," + age + ")";
            if (cowName_tb.Text == "" || earTag_tb.Text == "" || cowColor_tb.Text == "" || breed_tb.Text == "" || age_tb.Text == "")
            {
                MessageBox.Show("Please fill Missing Values");
            }
            else
            {
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Cows Data Saved Sucessfully.");
                    con.Close();
                     show();
                    clear();
                }
                catch (Exception exc)
                {
                    MessageBox.Show(exc.Message);
                }
                finally
                {
                    con.Close();
                }
            }
        }

        private void DOB_ValueChanged(object sender, EventArgs e)
        {
            age = Convert.ToDecimal((DateTime.Today.Date - DOB.Value.Date).Days) / 365;
        }

        private void DOB_MouseLeave(object sender, EventArgs e)
        {
            age = Convert.ToDecimal((DateTime.Today.Date - DOB.Value.Date).Days) / 365;
            age_tb.Text = "" + age;
        }

        private void show()
        {
            con.Open();
            string showQ = "Select * from CowsManage_Table";
            SqlCommand cmd = new SqlCommand(showQ, con);
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            adp.Fill(dt);
            CowList_dgv.DataSource = dt;
            con.Close();
        }
        private void clear()
        {
            cowName_tb.Text = "";
            cowColor_tb.Text = "";
            earTag_tb.Text = "";
            breed_tb.Text = "";
            age_tb.Text = "";
            key = 0;
        }

        private void show_lists_Click(object sender, EventArgs e)
        {

        }
        
        private void CowList_dgv_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }
        int key = 0;
        private void CowList_dgv_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            cowName_tb.Text = CowList_dgv.SelectedRows[0].Cells[1].Value.ToString();
            earTag_tb.Text = CowList_dgv.SelectedRows[0].Cells[2].Value.ToString();
            cowColor_tb.Text = CowList_dgv.SelectedRows[0].Cells[3].Value.ToString();
            breed_tb.Text = CowList_dgv.SelectedRows[0].Cells[4].Value.ToString();
            age_tb.Text = CowList_dgv.SelectedRows[0].Cells[5].Value.ToString();
            if (cowName_tb.Text == "")
            {
                key = 0;
                age = 0;
            }
            else
            {
                key = Convert.ToInt32(CowList_dgv.SelectedRows[0].Cells[0].Value.ToString());  
            }
        }

        private void delete_btn_Click(object sender, EventArgs e)
        {
            if (cowName_tb.Text == "")
            {
                MessageBox.Show("Please select Data to be Deleted!!");
            }
            else
            {
                con.Open();
                string showQ = "DELETE CowsManage_Table WHERE CowID = '" + key + "';";
                SqlCommand cmd = new SqlCommand(showQ, con);
                SqlDataAdapter adp = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                adp.Fill(dt);
                CowList_dgv.DataSource = dt;
                con.Close();
                MessageBox.Show("Cows Data Deleted Sucessfully!!");
                show();
                clear();
            }
        }

        private void update_btn_Click(object sender, EventArgs e)
        {

            if (cowName_tb.Text == "" || earTag_tb.Text == "" || cowColor_tb.Text == "" || breed_tb.Text == "" || age_tb.Text == "")
            {
                MessageBox.Show("Please select Data to be Updated!!");
            }
            else
            {
                try
                {
                    con.Open();
                    string query = "update CowsManage_Table set CowName = '" + cowName_tb.Text + "',EarTag = '" + earTag_tb.Text + "', Color ='" + cowColor_tb.Text + "', Breed = '" + breed_tb.Text + "',Age = '" + age_tb.Text + "' where CowID = '"+key+"'";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Cows Data Updated Sucessfully.");
                    con.Close();
                    show();
                    clear();

                }
                catch (Exception exc)
                {
                    MessageBox.Show(exc.Message);
                }
                finally
                {
                    con.Close();
                }
            }
        }

        private void logOut_btn_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}