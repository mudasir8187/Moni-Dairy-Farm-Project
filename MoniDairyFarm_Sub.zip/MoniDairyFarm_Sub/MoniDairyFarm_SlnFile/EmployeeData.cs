﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MoniDairyForm
{
    public partial class EmployeeData : Form
    {
        SqlConnection con = new SqlConnection("Data Source = MONI\\SQLEXPRESS02; Initial Catalog = MoniDiaryFarm;Encrypt=False; Integrated Security = True");
        public EmployeeData()
        {
            InitializeComponent();
            show();
        }

        private void show()
        {
            con.Open();
            string showQ = "Select * from Emps_Table";
            SqlCommand cmd = new SqlCommand(showQ, con);
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            adp.Fill(dt);
            employee_dgv.DataSource = dt;
            con.Close();
        }
        private void clear()
        {
            empsID_cb.Text = "";
            empName_tb.Text= "";
            empGender_cb.Text = "";
            contactNo_tb.Text = "";
            empAddress_tb.Text = "";
            empPass_tb.Text = "";
            key = 0;
        }
        private void save_btn_Click(object sender, EventArgs e)
        {
            string query = "insert into Emps_Table Values('" +empsID_cb.Text + "','" + empName_tb.Text + "','" + EmpDOB_date.Value.Date + "','" + empGender_cb.Text + "', '"+contactNo_tb.Text+ "','"+empAddress_tb.Text+"', '"+empPass_tb.Text+"' )";
            if (empsID_cb.Text == "" || empName_tb.Text == "" || empGender_cb.Text == "" || contactNo_tb.Text == "" || empAddress_tb.Text == "" || empPass_tb.Text == "")
            {
                MessageBox.Show("Please fill Missing Values");
            }
            else
            {
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Employees Data Saved Sucessfully.");
                    con.Close();
                    show();
                    clear();
                }
                catch (Exception exc)
                {
                    MessageBox.Show(exc.Message);
                }
                finally
                {
                    con.Close();
                }
            }
        }
        int key = 0;
        private void employee_dgv_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            empsID_cb.Text = employee_dgv.SelectedRows[0].Cells[0].Value.ToString();
            empName_tb.Text = employee_dgv.SelectedRows[0].Cells[1].Value.ToString();
            EmpDOB_date.Text = employee_dgv.SelectedRows[0].Cells[2].Value.ToString();
            empGender_cb.Text = employee_dgv.SelectedRows[0].Cells[3].Value.ToString();
            contactNo_tb.Text = employee_dgv.SelectedRows[0].Cells[4].Value.ToString();
            empAddress_tb.Text = employee_dgv.SelectedRows[0].Cells[5].Value.ToString();
            empPass_tb.Text = employee_dgv.SelectedRows[0].Cells[6].Value.ToString();
            if (empName_tb.Text == "")
            {
                key = 0;
            }
            else
            {
                key = Convert.ToInt32(employee_dgv.SelectedRows[0].Cells[0].Value.ToString());
            }
        }

        private void update_btn_Click(object sender, EventArgs e)
        {
            if (empsID_cb.Text == "" || empName_tb.Text == "" || empGender_cb.Text == "" || contactNo_tb.Text == "" || empAddress_tb.Text == "" || empPass_tb.Text == "")
            {
                MessageBox.Show("Please select Data to be Updated!!");
            }
            else
            {
                try
                {
                    con.Open();
                    string query = "update Emps_Table set EmpID = '" + empsID_cb.Text + "', EmpName = '" + empName_tb.Text + "', EmpDOB ='" + EmpDOB_date.Text + "', Gender = '" + empGender_cb.Text + "', ContactNo = '" + contactNo_tb.Text + "', Address = '"+empAddress_tb.Text+ "', Password = '"+empPass_tb.Text+"' where EmpID = '" + key + "'";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show(" Employees Data Updated Sucessfully.");
                    con.Close();
                    show();
                    clear();

                }
                catch (Exception exc)
                {
                    MessageBox.Show(exc.Message);
                }
                finally
                {
                    con.Close();
                }
            }
        }

        private void delete_btn_Click(object sender, EventArgs e)
        {
            if (empName_tb.Text == "")
            {
                MessageBox.Show("Please select Data to be Deleted!!");
            }
            else
            {
                con.Open();
                string showQ = "DELETE Emps_Table WHERE EmpID = '" + key + "';";
                SqlCommand cmd = new SqlCommand(showQ, con);
                SqlDataAdapter adp = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                adp.Fill(dt);
                employee_dgv.DataSource = dt;
                con.Close();
                MessageBox.Show("Employee Data Deleted Sucessfully!!");
                show();
                clear();
            }
        }

        private void EmployeeData_Load(object sender, EventArgs e)
        {

        }

        private void logOut_btn_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
