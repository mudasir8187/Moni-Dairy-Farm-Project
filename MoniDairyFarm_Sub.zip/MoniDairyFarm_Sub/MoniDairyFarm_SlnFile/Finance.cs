﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MoniDairyForm
{
    public partial class Finance : Form
    {
        SqlConnection con = new SqlConnection("Data Source = MONI\\SQLEXPRESS02; Initial Catalog = MoniDiaryFarm;Encrypt=False; Integrated Security = True");
        public Finance()
        {
            InitializeComponent();
            show();
            ExpendShow();
        }

        private void panel8_Paint(object sender, PaintEventArgs e)
        {

        }

        private void cow_side_label_Click(object sender, EventArgs e)
        {
            Cows obj = new Cows();
            obj.Show();
            this.Hide();
        }

        private void milk_sideLabel_Click(object sender, EventArgs e)
        {
            MilkProduction obj = new MilkProduction();
            obj.Show();
            this.Hide();
        }

        private void breeding_sideLabel_Click(object sender, EventArgs e)
        {
            Breeding obj = new Breeding();
            obj.Show();
            this.Hide();
        }

        private void sales_sideLabel_Click(object sender, EventArgs e)
        {
            Sales obj = new Sales();
            obj.Show();
            this.Hide();
        }

        private void Finance_Load(object sender, EventArgs e)
        {

        }
        private void show()
        {
            con.Open();
            string showQ = "Select * from Income_Table";
            SqlCommand cmd = new SqlCommand(showQ, con);
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            adp.Fill(dt);
            incomeList_dgv.DataSource = dt;
            con.Close();
        }
        private void clear()
        {
            incomeType_cb.Text = "";
            IncomeAmount_tb.Text = "";
        }

        private void IncomeSave_btn_Click(object sender, EventArgs e)
        {
            if (incomeType_cb.SelectedIndex == -1 || incomeType_cb.Text == "")
            {
                MessageBox.Show("Please fill Missing Values");
            }
            else
            {
                try
                {
                    con.Open();
                    string query = "insert into Income_Table Values('" + income_Date.Value.Date + "','" + incomeType_cb.Text + "','" + IncomeAmount_tb.Text + "')";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show(" Income Data Saved Sucessfully.");
                    con.Close();
                    show();
                    clear();
                }
                catch (Exception exc)
                {
                    MessageBox.Show(exc.Message);
                }
                finally
                {
                    con.Close();
                }
            }
        }
        private void ExpendShow()
        {
            con.Open();
            string showQ = "Select * from Expenditure_Table ";
            SqlCommand cmd = new SqlCommand(showQ, con);
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            adp.Fill(dt);
            expendList_dgv.DataSource = dt;
            con.Close();
        }
        private void ExpendSave_btn_Click(object sender, EventArgs e)
        {
            if (ExpendCategory_cb.SelectedIndex == -1 || expenditureAmount_tb.Text == "")
            {
                MessageBox.Show("Please fill Missing Values");
            }
            else
            {
                try
                {
                    con.Open();
                    string query = "insert into Expenditure_Table Values('" + expenditure_date.Value.Date + "','" + ExpendCategory_cb.Text + "','" + expenditureAmount_tb.Text + "')";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show(" Expenditure Data Saved Sucessfully.");
                    con.Close();
                    ExpendShow();
                    clear();
                }
                catch (Exception exc)
                {
                    MessageBox.Show(exc.Message);
                }
                finally
                {
                    con.Close();
                }
            }
        }
    }
}
