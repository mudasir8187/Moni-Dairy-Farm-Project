﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace MoniDairyForm
{
    public partial class LoginPage : Form
    {
        SqlConnection con = new SqlConnection("Data Source = MONI\\SQLEXPRESS02; Initial Catalog = MoniDiaryFarm;Encrypt=False; Integrated Security = True");
        public LoginPage()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void LoginPage_Load(object sender, EventArgs e)
        {

        }

        private void Login_btn_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("select * from Login_Table where User_Name ='" + userName_tb.Text + "' and Password ='" + password_tb.Text + "'", con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            string role = Role_cb.SelectedItem.ToString();
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    if (dt.Rows[i]["Role"].ToString() == role)
                    {
                        MessageBox.Show("You are login as " + dt.Rows[i][2]);
                        if (Role_cb.SelectedIndex == 0)
                        {
                            EmployeeData emp = new EmployeeData();
                            emp.Show();
                            this.Hide();
                        }
                        else
                        {
                            Cows cw = new Cows();
                            cw.Show();
                            this.Hide();
                        }

                    }
                }

            }
            else
            {
                MessageBox.Show("Invalid Credentials!!");
            }

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
