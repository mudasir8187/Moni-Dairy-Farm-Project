﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Schema;

namespace MoniDairyForm
{
    public partial class MilkProduction : Form
    {
        SqlConnection con = new SqlConnection("Data Source = MONI\\SQLEXPRESS02; Initial Catalog = MoniDiaryFarm;Encrypt=False; Integrated Security = True");
        public MilkProduction()
        {
            InitializeComponent();
            show();
            FillCowID();
        }

        private void cow_sideLabel_Click(object sender, EventArgs e)
        {
             Cows obj = new Cows();
             obj.Show();
              this.Hide();
        }

        private void breeding_sideLabel_Click(object sender, EventArgs e)
        {
            Breeding obj = new Breeding();
            obj.Show();
            this.Hide();
        }

        private void sale_sideLabel_Click(object sender, EventArgs e)
        {
            Sales obj = new Sales();
            obj.Show();
            this.Hide();
        }

        private void finance_sideLabel_Click(object sender, EventArgs e)
        {
            Finance obj = new Finance();
            obj.Show();
            this.Hide();
        }
       
        private void MilkProduction_Load(object sender, EventArgs e)
        {

        }
        private void FillCowID()
        {
            con.Open();
            string query = "select CowID from CowsManage_Table";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader reader;
            reader = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Columns.Add("CowID", typeof(int));
            dt.Load(reader);
            cowID_cb.ValueMember = "CowID";
            cowID_cb.DataSource = dt;
            con.Close();
        }
        private void show()
        {
            con.Open();
            string showQ = "Select * from Milk_table";
            SqlCommand cmd = new SqlCommand(showQ, con);
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            adp.Fill(dt);
            milkList_dgv.DataSource = dt;
            con.Close();
        }
        private void clear()
        {
            cowID_cb.Text = "";
            cowName_tb.Text = "";
            am_tb.Text = "";
            pm_tb.Text = "";
            total_tb.Text = "";
            key = 0;
        }
        private void getName()
        {
            con.Open();
            string query = "select * from CowsManage_Table where CowID ="+cowID_cb.SelectedValue.ToString()+"";
            SqlCommand cmd = new SqlCommand(query, con);
            DataTable dt = new DataTable();
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            adp.Fill(dt);
            foreach(DataRow dr in dt.Rows)
            {
                cowName_tb.Text = dr["CowName"].ToString();
            }
            con.Close();
        }
        private void save_btn_Click(object sender, EventArgs e)
        {
           
            if (cowID_cb.SelectedIndex == -1 || cowName_tb.Text == "" || am_tb.Text == "" || pm_tb.Text == "" || total_tb.Text == "")
            {
                MessageBox.Show("Please fill Missing Values");
            }
            else
            {
                try
                {
                    con.Open();
                    string query = "insert into Milk_table Values('" + cowID_cb.SelectedValue.ToString() + "','" + cowName_tb.Text + "','" + am_tb.Text + "','" + pm_tb.Text + "','" + total_tb.Text + "','" + milk_date.Value.Date + "')";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show(" Milk Data Saved Sucessfully.");
                    con.Close();
                    show();
                    clear();
                }
                catch (Exception exc)
                {
                    MessageBox.Show(exc.Message);
                }
                finally
                {
                    con.Close();
                }
            }
        }

        private void cowID_cb_SelectionChangeCommitted(object sender, EventArgs e)
        {
            getName();
        }

        private void pm_tb_MouseLeave(object sender, EventArgs e)
        {
            
        }
        
        private void pm_tb_Leave(object sender, EventArgs e)
        {
            int total_milk = Convert.ToInt32(am_tb.Text) + Convert.ToInt32(pm_tb.Text);
            total_tb.Text = "" + total_milk;
        }
        
        private void milkList_dgv_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }
        int key = 0;
        private void milkList_dgv_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            cowID_cb.SelectedValue = milkList_dgv.SelectedRows[0].Cells[0].Value.ToString();
            cowName_tb.Text = milkList_dgv.SelectedRows[0].Cells[1].Value.ToString();
            am_tb.Text = milkList_dgv.SelectedRows[0].Cells[2].Value.ToString();
            pm_tb.Text = milkList_dgv.SelectedRows[0].Cells[3].Value.ToString();
            total_tb.Text = milkList_dgv.SelectedRows[0].Cells[4].Value.ToString();
            milk_date.Text = milkList_dgv.SelectedRows[0].Cells[5].Value.ToString();
            if (cowName_tb.Text == "")
            {
                key = 0;
            }
            else
            {
                key = Convert.ToInt32(milkList_dgv.SelectedRows[0].Cells[0].Value.ToString());
            }
        }

        private void update_btn_Click(object sender, EventArgs e)
        {
            if (cowID_cb.SelectedIndex == -1 || cowName_tb.Text == "" || am_tb.Text == "" || pm_tb.Text == "" || total_tb.Text == "")
            {
                MessageBox.Show("Please select Data to be Updated!!");
            }
            else
            {
                try
                {
                    con.Open();
                    string query = "update Milk_table set CowID = '" + cowID_cb.Text + "', CowName = '" + cowName_tb.Text + "', AMMilk ='" +am_tb.Text + "', PMMilk = '" + pm_tb.Text + "', TotalMilk = '" + total_tb.Text + "',Date = '"+milk_date.Text+"' where CowID = '" + key + "'";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Milk Data Updated Sucessfully.");
                    con.Close();
                    show();
                    clear();

                }
                catch (Exception exc)
                {
                    MessageBox.Show(exc.Message);
                }
                finally
                {
                    con.Close();
                }
            }
        }

        private void delete_btn_Click(object sender, EventArgs e)
        {
            if (cowID_cb.SelectedIndex == -1 || cowName_tb.Text == "" || am_tb.Text == "" || pm_tb.Text == "" || total_tb.Text == "")
            {
                MessageBox.Show("Please select Data to be Deleted!!");
            }
            else
            {
                con.Open();
                string showQ = "DELETE Milk_table WHERE CowID = '" + key + "';";
                SqlCommand cmd = new SqlCommand(showQ, con);
                SqlDataAdapter adp = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                adp.Fill(dt);
                milkList_dgv.DataSource = dt;
                con.Close();
                MessageBox.Show("Milk Data Deleted Sucessfully!!");
                show();
                clear();
            }
        }
    }
}
