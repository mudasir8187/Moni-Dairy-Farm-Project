﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MoniDairyForm
{
    public partial class Sales : Form
    {
        SqlConnection con = new SqlConnection("Data Source = MONI\\SQLEXPRESS02; Initial Catalog = MoniDiaryFarm;Encrypt=False; Integrated Security = True");
        public Sales()
        {
            InitializeComponent();
            show();
            FillCowID();
        }

        private void Sales_Load(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void cow_sideLabel_Click(object sender, EventArgs e)
        {
            Cows obj = new Cows();
            obj.Show();
            this.Hide();
        }

        private void milk_sideLabel_Click(object sender, EventArgs e)
        {
            MilkProduction obj = new MilkProduction();
            obj.Show();
            this.Hide();
        }

        private void breeding_sideLabel_Click(object sender, EventArgs e)
        {
            Breeding obj = new Breeding();
            obj.Show();
            this.Hide();
        }

        private void finance_sideLabel_Click(object sender, EventArgs e)
        {
            Finance obj = new Finance();
            obj.Show();
            this.Hide();
        }
        private void show()
        {
            con.Open();
            string showQ = "Select * from Sales_Table";
            SqlCommand cmd = new SqlCommand(showQ, con);
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            adp.Fill(dt);
            sales_dgv.DataSource = dt;
            con.Close();
        }
        private void clear()
        {
            clientName_tb.Text = "";
            price_tb.Text = "";
            contactNo_tb.Text = "";
            quantity_tb.Text = "";
            total_tb.Text = "";
        }
        private void FillCowID()
        {
            con.Open();
            string query = "select CowID from CowsManage_Table";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader reader;
            reader = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Columns.Add("CowID", typeof(int));
            dt.Load(reader);
            salesID_cb.ValueMember = "CowID";
            salesID_cb.DataSource = dt;
            con.Close();
        }

        private void save_btn_Click(object sender, EventArgs e)
        {
            if (salesID_cb.SelectedIndex == -1 ||  clientName_tb.Text == "" || price_tb.Text == "" || contactNo_tb.Text == "" || quantity_tb.Text == "" || total_tb.Text == "")
            {
                MessageBox.Show("Please fill Missing Values");
            }
            else
            {
                try
                {
                    con.Open();
                    string query = "insert into Sales_Table Values('" + salesID_cb.SelectedValue.ToString() + "','" + sale_date.Value.Date + "','" + clientName_tb.Text + "','" + price_tb.Text + "','" + contactNo_tb.Text + "','" + quantity_tb.Text + "','" + total_tb.Text + "')";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show(" Sales Data Saved Sucessfully.");
                    con.Close();
                    show();
                    clear();
                }
                catch (Exception exc)
                {
                    MessageBox.Show(exc.Message);
                }
                finally
                {
                    con.Close();
                }
            }
        }

        private void quantity_tb_Leave(object sender, EventArgs e)
        {
            int total_price = Convert.ToInt32(price_tb.Text) * Convert.ToInt32(quantity_tb.Text);
            total_tb.Text = "" + total_price;
        }
        int key = 0;
        private void sales_dgv_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            salesID_cb.Text = sales_dgv.SelectedRows[0].Cells[0].Value.ToString();
            sale_date.Text = sales_dgv.SelectedRows[0].Cells[1].Value.ToString();
            clientName_tb.Text = sales_dgv.SelectedRows[0].Cells[2].Value.ToString();
            price_tb.Text = sales_dgv.SelectedRows[0].Cells[3].Value.ToString();
            contactNo_tb.Text = sales_dgv.SelectedRows[0].Cells[4].Value.ToString();
            quantity_tb.Text = sales_dgv.SelectedRows[0].Cells[5].Value.ToString();
            total_tb.Text = sales_dgv.SelectedRows[0].Cells[6].Value.ToString();
            if (clientName_tb.Text == "")
            {
                key = 0;
            }
            else
            {
               key = Convert.ToInt32(sales_dgv.SelectedRows[0].Cells[0].Value.ToString());
            }
        }

        private void update_btn_Click(object sender, EventArgs e)
        {
            if (salesID_cb.SelectedIndex == -1 || clientName_tb.Text == "" || price_tb.Text == "" || contactNo_tb.Text == "" || quantity_tb.Text == "" || total_tb.Text == "")
            {
                MessageBox.Show("Please select Data to be Updated!!");
            }
            else
            {
                try
                {
                    con.Open();
                    string query = "update Sales_Table set Date = '" + sale_date.Text + "', ClientName = '" + clientName_tb.Text + "', Price ='" + price_tb.Text + "', ContactNo = '" + contactNo_tb.Text + "', Quantity = '" + quantity_tb.Text + "', Total = '" + total_tb.Text + "' where SalesID = '" + key + "'";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Sales Data Updated Sucessfully.");
                    con.Close();
                    show();
                    clear();

                }
                catch (Exception exc)
                {
                    MessageBox.Show(exc.Message);
                }
                finally
                {
                    con.Close();
                }
            }
        }

        private void delete_btn_Click(object sender, EventArgs e)
        {
            if (salesID_cb.SelectedIndex == -1 || clientName_tb.Text == "" || price_tb.Text == "" || contactNo_tb.Text == "" || quantity_tb.Text == "" || total_tb.Text == "")
            {
                MessageBox.Show("Please select Data to be Deleted!!");
            }
            else
            {
                con.Open();
                string showQ = "DELETE Sales_Table WHERE SalesID = '" + key + "';";
                SqlCommand cmd = new SqlCommand(showQ, con);
                SqlDataAdapter adp = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                adp.Fill(dt);
                sales_dgv.DataSource = dt;
                con.Close();
                MessageBox.Show("Sales Data Deleted Sucessfully!!");
                show();
                clear();
            }
        }
    }
}
