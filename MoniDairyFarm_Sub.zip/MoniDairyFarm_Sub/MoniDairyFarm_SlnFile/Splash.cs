namespace MoniDairyForm
{
    public partial class Splash : Form
    {
        public Splash()
        {
            InitializeComponent();
            
        }
        private void progress()
        {
            progressBar1.Increment(3);
            loading_label.Text = "Loading..." + progressBar1.Value.ToString() + "%";
            if (progressBar1.Value == progressBar1.Maximum)
            {
                timer1.Stop();
                LoginPage log = new LoginPage();
                log.Show();
                this.Hide();
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            progress();
        }

        private void Splash_Load(object sender, EventArgs e)
        {

        }
    }
}